const initialCards = [
  {
    name: 'Андромеда',
    link: 'https://images.unsplash.com/photo-1604423203943-54721eff418a?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1949&q=80'
  },
  {
    name: 'Луна',
    link: 'https://images.unsplash.com/photo-1481819613568-3701cbc70156?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'Сомбреро',
    link: 'https://images.unsplash.com/photo-1560740583-0664e57560e4?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=1003&q=80'
  },
  {
    name: 'Земля',
    link: 'https://images.unsplash.com/photo-1564053489984-317bbd824340?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=514&q=80'
  },
  {
    name: 'Млечный путь',
    link: 'https://images.unsplash.com/photo-1543985041-cdbf9389b36f?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'
  },
  {
    name: 'Солнце',
    link: 'https://images.unsplash.com/photo-1575881875475-31023242e3f9?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80'
  }
];

export default initialCards;
